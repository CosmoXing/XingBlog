---
name: logisim-circuit-design
description: 用代码生成/修改 Logisim-evolution (.circ) 数字电路，并做真值表与测试向量验证。适用于给用户画组合逻辑（全加器、BCD 加法器、译码器、多路选择器）、搭建门级分层电路（子电路模块化）、满足“不许用现成芯片/不许用隧道”的作业要求、修复 .circ 打开报错或位宽不兼容、以及需要模块截图/用例电路的场景。关键词：logisim、.circ、电路作业、真值表、测试向量、数码管、子电路、分线器、全加器。
agent_created: true
---

# Logisim 电路设计

## 何时用

- 用户要求用 Logisim 做电路（作业、课设、演示），尤其是「只许门电路、不许用现成运算器件、不许用隧道」这类限制。
- 已有 `.circ` 打不开、显示 `E` / 橙色「位宽不兼容」、模块引脚接不上、数码管不亮。
- 需要批量生成测试用例电路、跑验证、出截图。

不适用：模拟电路（SPICE）、Verilog/VHDL 综合。

## 环境探测（先做，10 秒）

```bash
ls -1 D:/app/logisim-evolution-*-all.jar 2>/dev/null      # 常见安装位
ls -1 "$HOME"/logisim*/*.jar 2>/dev/null
echo "$LOGISIM_JAR"                                        # 桥接器用的环境变量
java -version                                              # jpackage 自带 runtime 常常没有 java.exe
```

版本看工程头 `<project source="5.0.0">`。3.9 与 5.0 的 `.circ` 基本互通，但**引脚写法不同**：5.0 用 `<a name="type" val="input"/>`，3.9 用 `output="true"`。新写一律用 5.0 写法。

## 核心工作流

1. **先定分层**：`顶层 → 功能模块 → 门级`。每层只用「≤3 入 / ≤2 出」的子电路，端口才可靠。
2. **用脚本生成 XML**，不要手写坐标：`scripts/logisim_gen.py` 提供 `pin/gate/sub/splitter/display/wire/project`。
3. **布线交给 `scripts/router.py`**（通道布线，自动避开共线重叠与端点压线），不要手算走线。
   **有布线失败就 `raise`，绝不写出文件**——断头导线会让 Logisim 加载时 `WireRepair` 死循环 OOM（`G.check(fails)` 已内置这条判断）。
4. **每层单独验证**：先 `verify.py table` 跑真值表，再拼上层。
5. **整机验证**：`verify.py vector <主电路> <x.vec> <工程.circ>`，必须「失败：0」才算完成。
6. **出图**：GUI 打开 → 缩放到一屏 → 截图；模块图 + 模块展开图各一张。
7. **交付**：主工程 `.circ` + 校验工程 `*_test.circ`（模块输出改接输出引脚）+ 若干常量写死的用例电路。

## 五条铁律（违反必炸）

| # | 铁律 | 后果 |
|---|---|---|
| 1 | 导线终点必须**精确落在端口像素**上 | 差 10px 就断线，且没有任何报错 |
| 2 | 子电路实例只做 **≤3 入 / ≤2 出** | 9 入 5 出的模块端口位置全错，输出恒 `U` |
| 3 | 导线**不要穿过**子电路端口 | `WireRepair.doOverlaps` 死循环 → OutOfMemoryError |
| 4 | 位宽严格匹配（数码管数据口恒 4 位） | 橙色「位宽不兼容」，整条网络 `E` |
| 5 | 生成的 `.circ` 必须自带 `<toolbar>` | 用户打开后没有绘图工具条，以为软件坏了 |

## 关键坐标速查

完整版见 `references/geometry.md`，这里只列必背项：

| 对象 | 坐标 |
|---|---|
| 2 输入门（AND/OR/XOR…） | `loc` 是**输出**口；输入口 `(loc.x-20, loc.y±20)`；入线画到 `loc.x-10` |
| NOT 门 | 输入口 `(loc.x-20, loc.y)` |
| 子电路实例 | 输入 `(loc.x-30, loc.y+10i)`；输出 `(loc.x, loc.y+10j)`；框宽恒 30；**y 间距是 10** |
| 分线器·拆位 | 合并侧 `loc`；分线侧 `(loc.x+20, loc.y-20+10i)`，`bit0` 在最上 |
| 分线器·合并 | 4 位从 `(loc.x+20, …)` 送入，`loc` 输出 4 位；位序 `o = i3 i2 i1 i0` |
| Hex Digit Display | `loc` = 数据口（固定 4 位）；小数点口 `(loc.x+20, loc.y)` |
| 导线连通 | 十字交叉**不**连；端点压线**会**连；共线重叠**会**连 |

## 用生成器

```python
import sys; sys.path.insert(0, "<skill>/scripts")
import logisim_gen as G

body  = G.pin(120, 60, "a")                 # 输入引脚
body += G.pin(120, 160, "s", "output")      # 输出引脚
body += G.gate(320, 100, "XOR")             # loc 是输出口
body += G.path((120, 60), (300, 100))       # 走线，可多段折线
open("demo.circ", "w", encoding="utf-8", newline="\n").write(
    G.project([("main", body)]))            # 自动补齐 lib / options / toolbar
```

生成器已封装：`pin gate sub splitter display constant power ground wire path translate strip_pins project`。

总线接口写法（4 位进、4 位出）：

```python
body += G.pin(120, 60, "a", width=4)
body += G.splitter(260, 60, 4, 4)           # 拆位：bit0 在 (280, 40)
body += G.splitter(600, 300, 4, 4)          # 反向当合并器
body += G.display(700, 300, "sum")          # 数码管，数据口固定 4 位
```

## 验证

```bash
python <skill>/scripts/verify.py table  fa.circ                 # 真值表，自动枚举输入
python <skill>/scripts/verify.py stats  demo.circ               # 元件/导线计数
python <skill>/scripts/verify.py vector main bcd4.vec demo_test.circ
# 末行期望：通过：7，失败：0
```

向量文件（首行表头 `名字[位宽]`，值可十进制或 `0x`）：

```
a3[4] a2[4] b3[4] b0[4] cin sum3[4] cout_o
0x1   0x2   0x5   0x8   0    0x6     0
```

校验工程的做法：把数码管/负载统统换成输出引脚，向量直接对引脚取值；展示工程另存一份，两者用同一套布线生成，避免「图好看但不通」。

## 常见症状 → 修法

| 症状 | 根因 | 修法 |
|---|---|---|
| 输出全 `U` | 模块端口没接上 | 数是不是 >3 入；端口 y 间距按 10 算 |
| 输出 `E` +「位宽不兼容」 | 位宽不匹配（常见 1 位接 4 位数码管） | 用分线器补零凑 4 位 |
| 打开报「加载电路文件出错」 | 目录里有 `.xxx.circ.autosave` | 删掉 autosave 再开 |
| 没有绘图工具条 | 文件缺 `<toolbar>` | 补 `lib="8"` 的 toolbar 块 |
| 电路贴画布左上角、引脚被面板挡 | 元件从 `(0,0)` 起画 | 整体 `translate(+120,+60)` |
| 打开要缩到 0.15 才看得全 | 内部尺寸过大 | 压到 2000×1600 内，行距 340 |
| 数码管不亮 | 组件名写错（`HexDigit`） | 正确名 `Hex Digit Display`，lib `5` |

含定位过程的 17 条完整坑表见 `references/pitfalls.md`。

## 三条不要做

- 不要用隧道（Tunnel）省事——多数作业明令禁止，必须画真导线。
- 不要为省元件把多个功能塞进 5 入以上模块——端口会错，且出错无提示。
- 不要只在顶层验证：分层电路必须**每层都验**，否则错误定位成本高 10 倍。

## 资源

- `references/circ-format.md` — `.circ` XML 结构、库索引、组件属性、toolbar、版本差异
- `references/geometry.md` — 端口/尺寸常量、布线语义、布局与压缩
- `references/verification.md` — CLI 参数、输出解析、GUI/截图、MCP 桥接
- `references/pitfalls.md` — 实战坑：症状 / 根因 / 定位 / 解决
- `scripts/logisim_gen.py`、`scripts/router.py`、`scripts/verify.py`
- `assets/full-adder.circ` — 已知可用（真值表 8/8）的最小参考工程
