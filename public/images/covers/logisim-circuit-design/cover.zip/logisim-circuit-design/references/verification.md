# 验证与运行环境

## 1. 命令行（最可靠，优先用这个）

```bash
JAR=D:/app/logisim-evolution-5.0.0-all.jar

java -jar $JAR -t table  X.circ                    # 真值表（主电路）
java -jar $JAR -t stats  X.circ                    # 元件统计
java -jar $JAR -w main vec.txt X.circ              # 测试向量
```

- `-t table` 会把**所有输入引脚的组合**枚举一遍（≤8 个输入时最实用），表头带位宽：`a[4]`。
- `-w` 的输出：末行 `通过：7，失败：0`；失败时逐条列出 `s = 0 (expected 1)`。中文在 Windows 上是 **GBK** 编码，管道里看到乱码就转码。
- **不要**给 `-w` 加 `-Djava.awt.headless=true`：内部会 `new Frame`，headless 直接抛 `HeadlessException`。
- `-n`（格式转换）会弹 Swing 对话框，命令行下必崩，别用。

`scripts/verify.py` 已经把上述封装好（自动找 jar、GBK 解码、解析结果）：

```bash
python scripts/verify.py table  fa.circ
python scripts/verify.py stats  demo.circ
python scripts/verify.py vector main bcd4.vec demo_test.circ
```

## 2. 向量文件 `.vec` 格式

```
a3[4] a2[4] a1[4] a0[4] b3[4] b2[4] b1[4] b0[4] cin sum3[4] sum2[4] sum1[4] sum0[4] cout_o
0x1   0x2   0x3   0x4   0x5   0x6   0x7   0x8   0    0x6   0x9   0x1   0x2   0
0x9   0x9   0x9   0x9   0x0   0x0   0x0   0x1   0    0x0   0x0   0x0   0x0   1
```

- 首行表头，格式 `名字[位宽]`，1 位可省略 `[1]`。
- 值：十进制或 `0x..` 十六进制；多位引脚必须写全值。
- 每行一个用例。**输出引脚也必须出现在表头并给出期望值**，否则不算验证。
- 表头名字必须与电路里引脚的 `label` 完全一致（区分大小写）。

## 3. 测试用例怎么设计

以一个 4 位 BCD 加法器为例，7 条就够覆盖所有边界（判题通常也是这么造的）：

| # | 输入 | 目的 |
|---|---|---|
| 1 | 1234 + 5678 | 常规无进位 |
| 2 | 9999 + 0001 | 全链进位到最高位 |
| 3 | 0 + 0 + cin=1 | 单个进位输入贯通 4 位 |
| 4 | 9999 + 9999 | 每位都产生进位 + 溢出 |
| 5 | 1239 + 1239 | 个位进位后 9+9 |
| 6 | 1999 + 2999 + cin=1 | 进位链与 cin 叠加 |
| 7 | 0 + 0 | 全零 |

原则：**常规值 1 条 + 每个边界单独 1 条**；边界包括 0、最大值、进位传播最长路径、cin=1、溢出。

## 4. 双工程策略（强烈建议）

| 文件 | 用途 | 内容 |
|---|---|---|
| `demo.circ` | 交作业/展示 | 数码管显示结果，好看 |
| `demo_test.circ` | 验证 | 同一套布线，数码管换成输出引脚 |

两者由**同一个生成函数**产出（只切换 `probe=True`），保证「好看的那份」和「通过验证的那份」电气完全一致。只验证一份、交另一份，是翻车高发点。

另外给每个测试用例单独做一个「常量写死」的电路（`case1_xxx.circ`）：输入引脚全换成 `Constant`，打开即显示结果，答辩时不用手点引脚。做法是从主工程复制一份，把 `<comp ... name="Pin">` 的输入行替换成 `Constant` 行。

## 5. GUI 运行与截图

- 启动：`D:/logisim-evolution.exe <文件.circ>`（jpackage 启动器），或 `java -jar <jar> <文件.circ>`。
- **坑：从工具里启动 GUI，命令一结束进程就被回收**，窗口一闪而过。必须用「后台常驻」方式启动（如 `run_in_background`），否则会被误判为「Logisim 崩溃」。
- 标题栏出现「未保存」通常是因为**文件在打开后被外部改写**，不是用户改的。处理：关掉重开（不要点保存，否则用旧内存覆盖新文件）。
- 截图：
  - `PrintWindow` 抓不到菜单弹窗和缩放按钮的即时变化；
  - 稳妥做法是 `PIL.ImageGrab.grab()` 全屏截，再按窗口坐标裁剪；
  - 截图前先把窗口调到需要的大小，缩放设固定倍数。

## 6. MCP 桥接（可选）

若本机已有 `logisim_mcp/server.py`（stdio JSON-RPC，零第三方依赖），可用工具：

| 工具 | 作用 |
|---|---|
| `logisim_info` | 版本 / jar 路径 |
| `circuit_summary` / `circuit_stats` | 电路结构、元件统计 |
| `circuit_truth_table` | 真值表 |
| `circuit_verify` / `circuit_test_vector` | 测试向量 |
| `circuit_build` | 由描述生成 .circ |
| `circuit_open_gui` | 打开 GUI |

没有桥接时，直接用命令行 + Python 生成，效果一样——**不要为了「用上 MCP」而绕路**。

## 7. 交付检查清单

- [ ] `verify.py vector` 失败 0
- [ ] 每层子电路单独跑过真值表
- [ ] 顶层无隧道（`grep -c "<comp.*Tunnel"` 为 0）
- [ ] 文件自带 toolbar，打开有绘图工具条
- [ ] 无 `.autosave` 残留
- [ ] 顶层缩放到 ×1 能一屏看全；子电路展开不需要缩到 0.5 以下
- [ ] 模块图 + 展开图各一张截图
- [ ] 用例电路双击即显示结果
